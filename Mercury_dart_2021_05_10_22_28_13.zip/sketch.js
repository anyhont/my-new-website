let mySound;
function preload() {
  soundFormats('mp3');
  mySound = loadSound('mysterious.mp3');
}

function setup() {
  let cnv = createCanvas(100, 100);
  cnv.mousePressed(canvasPressed);
  
  background(220);
  text('tap here to play', 10, 20);
}

function canvasPressed() {
  mySound.play();
}
 